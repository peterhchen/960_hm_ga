"""
File Name: ga_rl.py
Description:
Input:
1. param_ID.json (ID = 0001, 0002, etc)
2. app.c
Output res_param_ID.csv
2/13/2022: by Peter H. Chen
"""
import os
import shutil
import subprocess
import json

gald_set = set(('num-cpus', 'mem-size', 'mem-type', \
    'sys-clock', 'cpu-type', 'num-l2caches', 'num-l3caches', \
    'l1i_size', 'l1i_assoc', 'l1d_size', 'l1d_assoc', \
    'l2_size', 'l2_assoc', 'l3_size', 'l3_assoc', \
    'cacheline_size'))
class GaRl:
    """
    Description:
       Gem5-Aladdin Reinforcement Learning.
    """
    def __int__(self):
        """
        Description: init
        """
        self.run_data = []

    def get_usr_name(self):
        """
        Description:
        Get environment variable user name (from defined USR_NAME).
        The USR_NAME is passed from docker run -e USR_NAME='pchen'...
        input_parameters: None
        return val (usr_name)
        """
        val = ''
        for key, val in os.environ.items():
            if 'USR_NAME' in key:
                return val
        return val

    def get_app_name(self):
        """
        Get environment variable app name (from defined APP_NAME).
        The APP_NAME is passed from docker run -e APP_NAME='app'...
        input_parameters: None
        return val (app_name)
        """
        val = ''
        for key, val in os.environ.items():
            if 'APP_NAME' in key:
                return val
        return val

    def get_param_file(self):
        """
        Get environment variable app name (from defined PARAM_FILE).
        The PARAM_FILE is passed from docker run -e APP_NAME='app'...
        input_parameters: None
        return val (param_file)
        """
        val = ''
        for key, val in os.environ.items():
            if 'PARAM_FILE' in key:
                return val
        return val

    def get_parameters(self, usr_name, app_name, param_file):
        """
        Description:
          In Dockerfile, ADD parameters_single.json to WORKDIR
          /workspace/gem5-aladdin/src/aladdin/integration-test/with-cpu/
          dse_dataset_load_store
          In container, we read param_ID.json frpm WORK_DIR
        """
        path_fn = os.path.join('/c_dse_dataset', usr_name, app_name, \
            param_file + '.json')
        # print('path_fn:', path_fn)
        with open(path_fn, 'r', encoding="utf-8") as in_file:
            param_data = json.load(in_file)
        return param_data

    def process_cacti(self, f_list):
        """
        Description:
            Parse feature list for Cacti.
        """
        for key in f_list:
            # print("process_fl => key:", key)
            if 'cacti' in key:
                self._process_cacti_param(key, f_list[key])

    def _process_cacti_param(self, key, cacti_ele):
        """
        Description:
        Repalce the size from the user specificaiton.
        Example:
        key: 'cacti cache size (bytes)':
          find_pat = 'size (bytes)'
          replace pattern: 'size (bytes) 16384'
        key: 'cacti tlb size (bytes):
          find_pat = 'size (bytes)'
          replace pattern: 'size (bytes) 256'
        key: 'cacti lq size (bytes):
          find_pat = 'size (bytes)'
          replace pattern: 'size (bytes) 128'
        key: 'cacti sq size (bytes):
          find_pat = 'size (bytes)'
          replace pattern: 'size (bytes) 64'
        """
        if os.environ['CACTI_DIR'] == '':
            print ('please source 01_docker_setup.bash first')
        # Note:
        # There are similar patterns.
        # "-size (bytes)"
        # "-block size (bytes)
        find_pat = '-size (bytes)'
        if 'cache' in key:
            rep_pat = find_pat + ' ' + str(cacti_ele)
            # print('cache rep_pat:', rep_pat)
            c_base = './template/test_cacti_cache.cfg.base'
            with open(c_base, 'r', encoding="utf-8") as filei:
                filedata = filei.read()
                filedata = filedata.replace(find_pat, rep_pat)
            cache_n = os.path.join(os.environ['CACTI_DIR'], \
                'test_cacti_cache.cfg')
            with open(cache_n, 'w', encoding="utf-8") as filew:
                filew.write(filedata)
        elif 'tlb' in key:
            rep_pat = find_pat + ' ' + str(cacti_ele)
            # print('tlb rep_pat:', rep_pat)
            tlb_base = './template/test_cacti_tlb.cfg.base'
            with open(tlb_base, 'r', encoding="utf-8") as filei:
                filedata = filei.read()
                filedata = filedata.replace(find_pat, rep_pat)
            tlb_n = os.path.join(os.environ['CACTI_DIR'], 'test_cacti_tlb.cfg')
            with open(tlb_n, 'w', encoding="utf-8") as filew:
                filew.write(filedata)
        elif 'lq' in key:
            rep_pat = find_pat + ' ' + str(cacti_ele)
            # print('lq rep_pat:', rep_pat)
            lq_base = './template/test_cacti_lq.cfg.base'
            with open(lq_base, 'r', encoding="utf-8") as filei:
                filedata = filei.read()
                filedata = filedata.replace(find_pat, rep_pat)
            lq_n = os.path.join(os.environ['CACTI_DIR'], 'test_cacti_lq.cfg')
            with open(lq_n, 'w', encoding="utf-8") as filew:
                filew.write(filedata)
        elif 'sq' in key:
            rep_pat = find_pat + ' ' + str(cacti_ele)
            # print('sq rep_pat:', rep_pat)
            sq_base = './template/test_cacti_sq.cfg.base'
            with open(sq_base, 'r', encoding="utf-8") as filei:
                filedata = filei.read()
                filedata = filedata.replace(find_pat, rep_pat)
            sq_n = os.path.join(os.environ['CACTI_DIR'], 'test_cacti_sq.cfg')
            with open(sq_n, 'w', encoding="utf-8") as filew:
                filew.write(filedata)

    def _is_gem5_aladdin(self, key):
        """
        Description: Check key is gem5-aladdin
        """
        if key in gald_set:
            return True
        return False

    def process_gem5_aladdin(self, f_list):
        """
        Description: Process run.sh.base into run.sh.
        """
        filedata = None
        run_base = './template/run.sh.base'
        with open(run_base, 'r', encoding="utf-8") as filei:
            filedata = filei.read()
        # print('f_list:', f_list)
        for key in f_list:
            # feature list contains cactic and gem5-aladdin
            rep_pat = ''
            if self._is_gem5_aladdin(key):
                # Select gem5-aladdin only
                rep_pat = str(key) + '=' + str(f_list[key])
                # print('rep_pat:', rep_pat)
                filedata = filedata.replace(key, rep_pat)
        with open('./run.sh', 'w', encoding="utf-8") as filew:
            filew.write(filedata)

    def run_sh(self, f_list):
        """
        Description: Run run.sh
        """
        subprocess.run(['sh', './run.sh'], check=True)
        inst_res = subprocess.run(['grep', 'sim_insts',\
            './outputs/stats.txt'], check=True, stdout=subprocess.PIPE,\
            universal_newlines=True)
        num_inst = inst_res.stdout.split()[1]
        cycle_res = subprocess.run(['grep', 'sim_ticks',\
            './outputs/stats.txt'], check=True, stdout=subprocess.PIPE,\
            universal_newlines=True)
        num_cycle = int(cycle_res.stdout.split()[1])/1000
        power_res = subprocess.run('grep "Avg Power:" ./outputs/*summary', \
            shell=True, check=True, stdout=subprocess.PIPE,\
            universal_newlines=True)
        _, _, power, power_unit = power_res.stdout.split()
        area_res = subprocess.run('grep "Total Area:" ./outputs/*summary', \
            shell=True, check=True, stdout=subprocess.PIPE,\
            universal_newlines=True)
        _, _, area, area_unit = area_res.stdout.split()
        results = {}
        ipc = float(num_inst)/float(num_cycle)
        for key in f_list:
            results[key] = f_list[key]
        results['num_ins'] = float(num_inst)
        results['num_cy'] = float(num_cycle)
        results['ipc'] = ipc
        results['power(' + power_unit + ')'] = power
        results['area(' + area_unit + ')'] = area
        return results

    def write_result(self, file_name, results):
        """
        Description: Write result in json format.
        """
        # print("results:", results)
        with open(file_name+'.csv', 'w', encoding="utf-8") as f_csv:
            for key in results:
                key = key.replace('cacti ', '').replace(' (bytes)', '')
                #f_csv.write('{:<15}'.format(str(key)+", "))
                f_csv.write(f'{str(key):<15}'+", ")
            f_csv.write("\n")
            for key in results:
                # f_csv.write('{:<15}'.format(str(results[key])+", "))
                f_csv.write('{str(results[key]):<15}'+", ")

        with open(file_name+'.json', 'w', encoding='utf-8') as f_out:
            json.dump(results, f_out, ensure_ascii=False, indent=4)

    def g5ald_hm(self):
        """
        Description: Write result in json format.
        """
        #usr_name = G_R.get_usr_name()
        #app_name = G_R.get_app_name()
        #param_file = G_R.get_param_file()
        usr_name = os.getenv("USR_NAME")
        app_name = os.getenv("APP_NAME")
        param_file = os.getenv("PARAM_FILE")
        # print("usr_name:", usr_name)
        # print("app_name:", app_name)
        # print("param_file:", param_file)
        json_dict = G_R.get_parameters(usr_name, app_name, param_file)
        # Get the feature list
        feat_list = json_dict['feature_list']
        G_R.process_cacti(feat_list)
        G_R.process_gem5_aladdin(feat_list)
        results = G_R.run_sh(feat_list)
        G_R.write_result("res_" + param_file, results)
        res_path = ''
        # print('usr_name:', usr_name)
        # print('app_name:', app_name)
        res_path = os.path.join('/c_dse_dataset', usr_name, app_name)
        # print('res_path:', res_path)
        shutil.copy('./res_' + param_file + '.csv', res_path)
        shutil.copy('./res_' + param_file + '.json', res_path)

if __name__ == "__main__":
    G_R = GaRl()
    G_R.g5ald_hm()
