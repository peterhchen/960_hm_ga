#!/bin/bash
# Create export environment
set -a
echo "01_docker_setenv.bash:"
USR_NAME="$(whoami)"
echo "USR_NAME: $USR_NAME"
APP_NAME="app"
echo "APP_NAME: $APP_NAME"
C_NAME="gem5-aladdin_param_"$USR_NAME
echo "C_NAME: $C_NAME"
WORK_DIR="/workspace/gem5-aladdin/src/aladdin/integration-test/with-cpu/dse_dataset_load_store"
#WORK_DIR="/home/pchen@usrd.futurewei.com/ga_rl"
CACTI_DIR="/workspace/gem5-aladdin/src/aladdin/integration-test/common/"
#CACTI_DIR="/home/pchen@usrd.futurewei.com/ga_rl/common/"
DSE_VOLUME="/var/lib/docker/volumes/dse_dataset/_data"
echo "DSE_VOLUME: $DSE_VOLUME"
# Inital parameter file name param.json
PARAM_FILE="param"
echo "PARAM_FILE: $PARAM_FILE"
if [ -d "${APP_NAME}" ]
then
    echo "Application ${APP_NAME} directory setup."
else
    echo "${APP_NAME} directory not found. Please setup first."
fi

if [ -f "${APP_NAME}/${APP_NAME}.c" ]
then
    echo "Application ${APP_NAME}/${APP_NAME} setup."
else
    echo "${APP_NAME}/${APP_NAME}.c not found. Please setup first."
fi

if [ -f "${APP_NAME}/${PARAM_FILE}" ]
then
    echo "Parameter File ${APP_NAME}/${PARAM_FILE} setup."
else
    echo "${APP_NAME}/${PARAM_FILE} not found. Please setup first."
fi
