#!/usr/bin/python
"""
Description: hypermapper for gem5-aladdin simulator
Created by Peter H. Chen 4/15/2022
"""
import os
import json
from hypermapper import optimizer  # noqa

RUN_COUNT_DEBUG_FLAG = True
RUN_COUNT = 0

def ga_sim ():
    """
    Description:
    gem5-aladdin simulator and result processing.
    """
    e_1 = os.getenv("USR_NAME")
    e_2 = os.getenv("APP_NAME")
    e_3 = os.getenv("CACTI_DIR")
    e_4 = os.getenv("PARAM_FILE")
    d_run = "docker run -it"
    env12 = " -e USR_NAME=" + e_1 + " -e APP_NAME=" + e_2
    env34 = " -e CACTI_DIR=" + e_3 + " -e PARAM_FILE=" + e_4
    cname = " --name " + os.getenv("C_NAME")
    vol_name = " -v dse_dataset:/c_dse_dataset"
    workdir = " --workdir=" + os.getenv("WORK_DIR")
    gald_param = " gem5-aladdin_param"
    r_cmd = d_run + env12 + env34 + cname + vol_name + workdir + " --rm " + gald_param
    # print("r_cmd:", r_cmd)
    print('docker run...\n')
    os.system(r_cmd)
    d_volume = os.getenv("DSE_VOLUME")
    u_name = os.getenv("USR_NAME")
    a_name = os.getenv("APP_NAME")
    param_file = os.getenv("PARAM_FILE")
    res_csv_fn = "res_" + param_file + ".csv"
    res_json_fn = "res_" + param_file + ".json"
    src_csv_path = os.path.join(d_volume, u_name, a_name, res_csv_fn)
    src_json_path = os.path.join(d_volume, u_name, a_name, res_json_fn)
    dest_path = os.path.join('.', a_name)
    csv_cmd = "cp " + src_csv_path + ' ' + dest_path
    json_cmd = "cp " + src_json_path + ' ' + dest_path
    # print('csv_cmd:', csv_cmd)
    # print('json_cmd:', json_cmd)
    print('\nCopy docker/volume result to local...\n')
    os.system(csv_cmd)
    os.system(json_cmd)

    ipc = 0.
    power = 0.
    area = 0.
    # res_csv_fn = "res_" + param_file + ".csv"
    res_json_fn = "res_" + param_file + ".json"
    i_file = os.path.join('.', a_name, res_json_fn)
    #with open ('./app/res_param_0001.json', encoding="utf-8") as f_read:
    with open (i_file, encoding="utf-8") as f_read:
        result_dict = json.load(f_read)
    print('Process Result...\n')
    print('resulti_dict:', result_dict)
    for key, val in result_dict.items():
        # print('key:', key, 'val:', val)
        if 'ipc' in key:
            ipc = float(val)
        elif 'power' in key:
            power = float(val)
        elif 'area' in key:
            area = float(val)
    return ipc, power, area

def ga_proc_sim(x_i):
    """
    Gem5-Aladdin Simulator.
    Input Parameter example:
    x_i["cpu-type"]: 'DerivO3CPU'         x_i["mem-type"]: 'DDR3_2133_8x8'
    x_i["cacti_cache_size_bytes"]: 16384  x_i["cacti_tlb_size_bytes"]: 512
    x_i["cacti_lq_size_bytes"]: 512       x_i["cacti_sq_size_bytes"]: 256
    x_i["sys-clock"]: 1GHz                x_i["num-cpus"]: 1
    x_i["mem-size"]: 64MB                 x_i["l1i_size"]: 8kB
    x_i["l1i_assoc"]: 8                   x_i["l1d_size"]: 4kB
    x_i["l1d_assoc"]: 16                  x_i["l2_size"]: 256kB
    x_i["l2_assoc"]: 8                    x_i["l3_size"]: 4096kB
    x_i["l3_assoc"]:  64                  x_i["cacheline_size"]: 64
    return: ipc, power, area
    """
    global RUN_COUNT
    if_name = './app/param.json.base'
    of_name = './app/param.json'

    with open(if_name, 'r', encoding="utf-8") as in_file:
        param_data = in_file.read()
    # print("before replace => param_data:", param_data)
    for key, val in x_i.items():
        #print('key:', key)
        #print('val:', val)
        if "cacheline_size" in key:
            # cacheline_size is the last line in json format, no ","
            rep_pat = '\"' + str(key) + '": "' + str(val) + '\"'
        else:
            rep_pat = '\"' + str(key) + '": "' + str(val) + '\",'
        #print('rep_pat:', rep_pat)
        param_data = param_data.replace(key, rep_pat)
    # print("after replace => param_data:", param_data)
    with open(of_name, 'w+', encoding="utf-8") as out_file:
        # print("write replace => param_data:", param_data)
        out_file.write(param_data)

    # Shell Copy app/param.json
    # to docker/volumes/dse_dataset/_data/pchen/app
    docker_vol = os.getenv("DSE_VOLUME")
    usr_name = os.getenv("USR_NAME")
    app_name = os.getenv("APP_NAME")
    dest_path = os.path.join(docker_vol, usr_name, app_name, 'param.json')
    cmd = "cp ./app/param.json " + dest_path
    # print('cmd:', cmd)
    os.system(cmd)
    if RUN_COUNT_DEBUG_FLAG is True:
        debug_name = "param_" + str(RUN_COUNT) + ".json"
        dest_path_debug = os.path.join(docker_vol, usr_name, app_name, debug_name)
        cmd_debug = "cp ./app/param.json" + " " + dest_path_debug
        print("cmd_debug:", cmd_debug)
        os.system(cmd_debug)
    # check_output(cmd, shell=True, executable="/bin/bash")
    print("Perform Gem5-Aladdin Simulation", RUN_COUNT, "...\n")
    RUN_COUNT += 1
    ipc, power, area = ga_sim ()

    return ipc, power, area

def hm_ga(x_i):
    """
    Compute the gem5-aladdin function.
    :param x_i: dictionary containing the input points.
    :return: the value of the gem5-aladdin simulator.
    x1 = x_i["cpu-type"]                    x2 = x_i["mem-type"]
    x3 = x_i["cacti_cache_size_bytes"]      x4 = x_i["cacti_tlb_size_bytes"]
    x5 = x_i["cacti_lq_size_bytes"]         x6 = x_i["cacti_sq_size_bytes"]
    x7 = x_i["sys-clock_GHz"]               x8 = x_i["num-cpus"]
    x9 = x_i["mem-size_GB"]                 x10 = x_i["l1i_size_kB"]
    x11 = x_i["l1i_assoc"]                  x12 = x_i["l1d_size_kB"]
    x13 = x_i["l1d_assoc"]                  x14 = x_i["l2_size_kB"]
    x15 = x_i["l2_assoc"]                   x16 = x_i["l3_size_kB"]
    x17 = x_i["l3_assoc"]                   x18 = x_i["cacheline_size"]
    """
    ipc = 0.
    power = 0.
    area = 0.
    # print('x_i:', x_i)
    ipc, power, area = ga_proc_sim(x_i)
    # output_metrics = {}
    # ipc: 0.53...
    # Avg Power: 18.3652 mW
    # Total area: 807763 uM^2
    # output_metrics["Area"] = area
    output_metrics = {}
    # hypermapper default is minimum optimization.
    # put negative (-) for maximum optimization.
    output_metrics["ipc"] = -ipc
    output_metrics["power"] = power
    output_metrics["area"] = area
    print('output_metrics:', output_metrics)

    return output_metrics

def main():
    """
    Description: main program for hypermapper.
    """
    parameters_file = "./hm_ga_scenario.json"
    optimizer.optimize(parameters_file, hm_ga)
    print("End of Hypermaper Gem5-Aladdin.")

if __name__ == "__main__":
    main()
