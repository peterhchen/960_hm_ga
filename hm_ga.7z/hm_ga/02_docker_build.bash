#!/bin/bash
# Usage:
# > source 02_docker_build.bash
# docker build will automatically call "Dokerfile" to build the image
# 
# Docker Build
# -t or --tage: Tag Name
#     gem5-aladdin_param
# --build-arg: Build the environment argument for docker from Linux
#   APP_NAME: Applicaiton name
#   WORK_DIR: Container working directory
#   CACTI_DIR: Container cacti directory
#   PARAM_FILE: parameter file name
docker build --tag gem5-aladdin_param . --build-arg APP_NAME=${APP_NAME} --build-arg WORK_DIR=${WORK_DIR} --build-arg CACTI_DIR=${CACTI_DIR} --build-arg PARAM_FILE=${PARAM_FILE}
