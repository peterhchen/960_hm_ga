#!/bin/bash
echo "source 01_docker_setenv.bash"
source 01_docker_setenv.bash
echo "source 02_docker_build.bash"
source 02_docker_build.bash
python hm_ga.py | tee info.txt
